#ifndef MAIN_H
#define MAIN_H

void ble_queue_reception();

#endif