
/******************************************************************************
* @file     cloud.h
* @author   Nestle Firmware Team
* @version  V1.0.0
* @date
* @brief   Header file for cloud interface
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __CLOUD_H
#define __CLOUD_H

#ifdef __cplusplus
 extern "C" {
#endif


/* Includes ------------------------------------------------------------------*/


/* Exported types ------------------------------------------------------------*/


/* Exported constants --------------------------------------------------------*/
 

/* Exported Variables --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

#define LPRINTF(format, ...) printf(format "\n", ##__VA_ARGS__)

/* Exported functions ------------------------------------------------------- */


#ifdef __cplusplus
}
#endif

#endif /* __CLOUD_H */

 