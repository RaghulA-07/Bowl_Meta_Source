#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <curl/curl.h>
#include <sys/stat.h>
#include <time.h>

#define CHECK_INTERVAL 5 // Check every 5 seconds
#define PROCESSED_FILES "processed_files.inc" // File to store processed file names

// Added by Raghul
#define AZURE_STORAGE_ACCOUNT "namsprdigsoluseasta"
#define AZURE_CONTAINER_NAME "pet-datalake"
#define AZURE_SAS_TOKEN "sp=racl&st=2024-05-14T07:40:36Z&se=2024-05-31T15:40:36Z&spr=https&sv=2022-11-02&sr=c&sig=HeA7l9JQpwRWXMjqP%2FcE80IfJQ4QJ2vUB8oWBqgzik0%3D"
#define AZURE_BLOB_NAME "landing/dog_bowl_test"

// Function declarations
void upload_file(const char *folder_path, const char *file_name);
int file_already_processed(const char *file_name);
void record_processed_file(const char *file_name);
int is_file_complete(const char *folder_path, const char *file_name);

int main(int argc, char *argv[]) {

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <folder_path>\n", argv[0]);
        return 1;
    }

    printf("\nStarting the cloudendpoint application...");

    const char *folder_path = argv[1];
    DIR *dir;
    struct dirent *ent;

    while (1) {
        if ((dir = opendir(folder_path)) != NULL) {
            while ((ent = readdir(dir)) != NULL) {
                if (ent->d_type == DT_REG) { // Check if it's a regular file
                    if (!file_already_processed(ent->d_name) &&
                        (strstr(ent->d_name, ".mp4") != NULL || strstr(ent->d_name, ".jpg") != NULL || strstr(ent->d_name, ".jpeg") != NULL || strstr(ent->d_name, ".txt") != NULL) &&
                        is_file_complete(folder_path, ent->d_name)) {
                        upload_file(folder_path, ent->d_name);
                        record_processed_file(ent->d_name);
                    }
                }
            }
            closedir(dir);
        } else {
            perror("Could not open directory");
            return EXIT_FAILURE;
        }

        sleep(CHECK_INTERVAL); // Wait for CHECK_INTERVAL seconds
    }

    return EXIT_SUCCESS;
}

void upload_file(const char *folder_path, const char *file_name) {
    // Determine the Content-Type based on the file extension
    const char *content_type = NULL;
    if (strstr(file_name, ".mp4") != NULL) {
        content_type = "Content-Type: video/mp4";
    } else if (strstr(file_name, ".txt") != NULL) {
        content_type = "Content-Type: text/plain";
    } else if (strstr(file_name, ".jpg") != NULL || strstr(file_name, ".jpeg") != NULL) {
        content_type = "Content-Type: image/jpeg";
    } else {
        fprintf(stderr, "Unsupported file type\n");
        return;
    }

    char full_file_path[1024];
    snprintf(full_file_path, sizeof(full_file_path), "%s/%s", folder_path, file_name);

    FILE *file = fopen(full_file_path, "rb");
    if (!file) {
        perror("\nError opening file");
        return;
    }

    // Calculate file size
    fseek(file, 0L, SEEK_END);
    long file_size = ftell(file);
    printf("\nFile size = %ld",file_size);
    rewind(file);

    // Initialize libcurl
    CURL *curl = curl_easy_init();
    if (!curl) {
        fprintf(stderr, "Error initializing libcurl\n");
        fclose(file);
        return;
    }

    printf("\n\nSetting up the cloud endpoint URL...");

    // Added by Raghul
    char url[256];
    snprintf(url, sizeof(url), "https://%s.blob.core.windows.net/%s/%s/%s?%s", AZURE_STORAGE_ACCOUNT, AZURE_CONTAINER_NAME, AZURE_BLOB_NAME, file_name, AZURE_SAS_TOKEN);
    curl_easy_setopt(curl, CURLOPT_URL, url);

    printf("\n\nCloud endpoint URL = %s\n\n",url);
 
    // Tell libcurl that we want to upload
    curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(curl, CURLOPT_READDATA, file);

    // Setting the upload file size
    curl_easy_setopt(curl, CURLOPT_INFILESIZE_LARGE, (curl_off_t)file_size);

    // Set custom headers
    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "x-ms-blob-type: BlockBlob");
    headers = curl_slist_append(headers, content_type);

    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

    // Enable verbose mode to dump HTTP request and response information
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

    // Perform the file upload
    CURLcode res = curl_easy_perform(curl);

    // Check for errors
    if (res != CURLE_OK) {
        fprintf(stderr, "\ncurl_easy_perform() failed: %s\n", curl_easy_strerror(res));
    } else {
        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        if (response_code == 200 || response_code == 201) {
            printf("\nUpload successful (HTTP response code %ld)\n", response_code);
        } else {
            printf("\nUpload failed with HTTP response code %ld\n", response_code);
        }
    }

    // Cleanup
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    fclose(file);
}

int file_already_processed(const char *file_name) {
    FILE *file = fopen(PROCESSED_FILES, "r");
    if (!file) {
        return 0;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0; // Remove newline character
        if (strcmp(line, file_name) == 0) {
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;
}

void record_processed_file(const char *file_name) {
    FILE *file = fopen(PROCESSED_FILES, "a");
    if (file) {
        printf("\nRecord processed file %p", file);
        fprintf(file, "%s\n", file_name);
        fclose(file);
    }
}

int is_file_complete(const char *folder_path, const char *file_name) {
    char file_path[1024];
    snprintf(file_path, sizeof(file_path), "%s/%s", folder_path, file_name);

    struct stat file_stat;
    int result = stat(file_path, &file_stat);
    printf("%d",result);
    if (result != 0) {
        return 0; // Error getting file info
    }

    time_t now;
    time(&now);
    double seconds = difftime(now, file_stat.st_mtime);

    return seconds > CHECK_INTERVAL; // File is considered complete if it was last modified longer ago than CHECK_INTERVAL
}
