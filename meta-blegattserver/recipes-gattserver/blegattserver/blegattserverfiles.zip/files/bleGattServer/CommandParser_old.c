#include "CommandParser.h"


#define MAX_SENSORS 7

const char* sensors[MAX_SENSORS] = {"Ambient Sensor", "IR Sensor", "Load Cell", "MIC", "IMU Sensor", "Camera 1", "Camera 2"};

void decodeSelection(int number) {
    int i;
    printf("Selected sensors: ");
    for (i = 0; i < MAX_SENSORS; i++) {
        // Check if the i-th bit is set in the number
        if ((number >> i) & 1) {
            printf("%s ,", sensors[i]);
        }
    }
    printf("\n");
}

// Dummy session data (assuming it's a global variable)
uint8_t sessionData[5][27] = {
    {0xAB, 0xCD, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x20, 0xd8, 0x3b, 0x3e, 0x87, 0xbc, 0x38, 0x7e, 0x72},
    {0x12, 0x34, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x25, 0x1e, 0x6d, 0xba, 0x44, 0x54, 0x4d, 0x9b, 0xaf},
    {0xDE, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x35, 0x9e, 0x43, 0x6f, 0xd5, 0x95, 0x07, 0xbc, 0x6a},
    {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x45, 0x42, 0xb0, 0x3a, 0x09, 0x89, 0x95, 0x79, 0xee},
    {0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x60, 0x0f, 0xf9, 0x94, 0x0b, 0x13, 0x7c, 0x2b, 0xe7}
};


void connectToWifi(const char *ssid, const char *password) {
    printf("Connecting to WiFi...\n");
    printf("SSID: %s\n", ssid);
    printf("Password: %s\n", password);
}

int isWiFiConnected() {
    return 1; // Assuming WiFi is always connected in this dummy implementation
}

void parseCommand(const uint8_t *data, int data_length, void (*readCallback)(const uint8_t *, size_t), void (*notifyCallback)(const uint8_t *, size_t)) {
    printf("Command Received\n");

    for (int i = 0; i < data_length; i++) {
        printf("%d ", data[i]); // Print the element
    }
    printf("\n");

    if (data_length == 0) {
        printf("Received empty data.\n");
        return;
    }
    if (data[0] != 0x01) { // Start of header check
        printf("Invalid start of header.\n");
        return;
    }
    if (data_length < 2 || data_length != data[1]) {
        printf("Data length mismatch.\n");
        return;
    }

    uint8_t cmd = data[3]; // CMD
    switch (cmd) {
        case 0x1B:
            startOrStopRecording(data, data_length, readCallback, notifyCallback);
            break;
        case 0x04:
            setWifiConfig(data, data_length, readCallback);
            break;
        case 0x02:
            getWifiConfig(data, data_length, readCallback);
            break;
        case 0x16:
            getDashboardInfoBowl(data, data_length, readCallback);
            break;
        case 0x1F:
            getTotalSessionsCount(data, data_length, readCallback);
            break;
        case 0x1C:
            getSessionByIndex(data, data_length, readCallback);
            break;
        case 0x05:
            getTimeSync(data,data_length,readCallback);
            break;
        case 0x06:
            setTimeSync(data,data_length,readCallback);
            break;
        default:
            printf("Unknown or unsupported command.\n");
            break;
    }
}

void startOrStopRecording(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t), void (*notifyCallback)(const uint8_t *, size_t)) {
    //bool startStop = data[12] == 0x01; // Start/Stop flag
    bool startStop = data[4] == 0x01; // Start/Stop flag

    uint8_t additionalData[1] = {0x00}; // Additional data for the acknowledgment

    if (startStop) {
        sendAck(0x1B, additionalData, sizeof(additionalData), readCallback);
        printf("Harvesting Started\n");
        uint8_t sensorbyte = data[13]; 
        decodeSelection(sensorbyte);
        
    } else {
        sendAck(0x1B, additionalData, sizeof(additionalData), readCallback);
        printf("Harvesting Stopped\n");

    }
}

void setWifiConfig(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t)) {
    char wifiSSID[21] = {0}; // 20 characters + null terminator
    size_t ssidLen = data[4];
    for (size_t i = 0; i <= 24 && i < 20; ++i) {
        wifiSSID[i] = (char)data[i + 5+(20-ssidLen)];
    }
    

    char wifiPassword[21] = {0}; // 20 characters + null terminator
    size_t wifiLen = data[25];
    for (size_t i = 0; i <= 45 && i < 20; ++i) {
        wifiPassword[i] = (char)data[i + 26+(20-wifiLen)];
    }

    // Print SSID and password
    printf("WiFi SSID: %s\n", wifiSSID);
    printf("WiFi Password: %s\n", wifiPassword);


    connectToWifi(wifiSSID, wifiPassword);
    printf("Status: %d\n", isWiFiConnected());

    uint8_t additionalData[1] = {0x00}; // Additional data for the acknowledgment
    sendAck(0x04, additionalData, sizeof(additionalData), readCallback);
}

void getWifiConfig(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t)) {
    uint8_t additionalData[45] = {0}; // Initialize all elements to 0

    if (isWiFiConnected()) {
        additionalData[42] = 0x01; // Index 43 in array (arrays are zero-based)
    }

    sendAck(0x02, additionalData, sizeof(additionalData), readCallback);
}

void getDashboardInfoBowl(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t)) {
    uint8_t additionalData[] = {
        // Device Name ASCII Chars ("DeviceName")
        0x44, 0x65, 0x76, 0x69, 0x63, 0x65, 0x4E, 0x61,
        // Device Model Type Code
        0x05,
        // Application Firmware major version
        0x01,
        // Application Firmware minor version
        0x0,
        // Application Firmware patch version
        0x0,
        // Battery level
        0x2E,
        // Battery voltage higher byte
        0x01,
        // Battery voltage lower byte
        0x02,
        // Input Power higher byte
        0x02,
        // Input Power lower byte
        0x06,
        // Temperature higher byte
        0x07,
        // Temperature lower byte
        0x08
    };
    sendAck(0x16, additionalData, sizeof(additionalData), readCallback);
}

void getTotalSessionsCount(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t)) {
    uint8_t additionalData[1] = {0x05};
    sendAck(0x1F, additionalData, sizeof(additionalData), readCallback);
}

void getSessionByIndex(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t)) {
    uint8_t element = data[4];
    int index = (int)element;

    if (index >= 0 && index < 5) {
        uint8_t additionalData[27];
        for (int i = 0; i < 27; ++i) {
            additionalData[i] = sessionData[index][i];
        }
        sendAck(0x1C, additionalData, sizeof(additionalData), readCallback);
    } else {
        printf("Invalid session index\n");
    }
}

void appendChecksumAndUpdateLength(uint8_t *packet, size_t packet_size) {
    packet[1] = (uint8_t)(packet_size + 2); // Update frame length
    uint16_t checksum = calculateChecksum(packet, packet_size);
    packet[packet_size] = (uint8_t)((checksum >> 8) & 0xFF); // CRC high byte
    packet[packet_size + 1] = (uint8_t)(checksum & 0xFF); // CRC low byte
}

uint16_t calculateChecksum(const uint8_t *data, size_t data_length) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < data_length; i++) {
        crc ^= data[i];

        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}


void setTimeSync(const uint8_t *data, size_t dataSize, void (*readCallback)(const uint8_t *, size_t)) {
    const uint8_t additionalData[] = {0x00};
    size_t additionalDataSize = sizeof(additionalData) / sizeof(additionalData[0]);
    
    sendAck(0x06, additionalData, additionalDataSize, readCallback);
}

void getTimeSync(const uint8_t *data, size_t dataSize, void (*readCallback)(const uint8_t *, size_t)) {
    const uint8_t additionalData[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    size_t additionalDataSize = sizeof(additionalData) / sizeof(additionalData[0]);
    
    sendAck(0x05, additionalData, additionalDataSize, readCallback);
}

void sendAck(uint8_t cmd, const uint8_t *data, size_t data_length, void (*readOrNotifyCallback)(const uint8_t *, size_t)) {
    uint8_t ackPacket[100];
    size_t ackPacketSize = 0;

    ackPacket[ackPacketSize++] = 0x02; // SOH
    ackPacket[ackPacketSize++] = 0x08; // Frame Length
    ackPacket[ackPacketSize++] = 0xF2; // FT
    ackPacket[ackPacketSize++] = cmd; // CMD

    if (cmd == 0x04) {
        if (isWiFiConnected()) {
            ackPacket[ackPacketSize++] = 0x11; // ACK
        } else {
            ackPacket[ackPacketSize++] = 0x12; // Error
        }
    } else {
        ackPacket[ackPacketSize++] = 0x11; // ACK
    }

    for (size_t i = 0; i < data_length; ++i) {
        ackPacket[ackPacketSize++] = data[i];
    }

    appendChecksumAndUpdateLength(ackPacket, ackPacketSize);

    readOrNotifyCallback(ackPacket, ackPacketSize+2);
}
