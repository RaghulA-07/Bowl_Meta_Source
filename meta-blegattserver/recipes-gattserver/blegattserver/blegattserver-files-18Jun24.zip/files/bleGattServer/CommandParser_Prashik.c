#include "CommandParser.h"

#define MAX_SENSORS 7

const char *sensors[MAX_SENSORS] = {"Ambient Sensor", "IR Sensor", "Load Cell", "MIC", "IMU Sensor", "Camera 1", "Camera 2"};

const char **decodeSelection(int number, int *selectedCount)
{
    const char **selectedSensors = (const char **)malloc(MAX_SENSORS * sizeof(const char *));
    if (!selectedSensors) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    int i, count = 0;
    for (i = 0; i < MAX_SENSORS; i++)
    {
        if ((number >> i) & 1)
        {
            selectedSensors[count++] = sensors[i];
        }
    }
    *selectedCount = count;
    return selectedSensors;
}
// Dummy session data (assuming it's a global variable)
uint8_t sessionData[5][27] = {
    {0xAB, 0xCD, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x20, 0xd8, 0x3b, 0x3e, 0x87, 0xbc, 0x38, 0x7e, 0x72},
    {0x12, 0x34, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x25, 0x1e, 0x6d, 0xba, 0x44, 0x54, 0x4d, 0x9b, 0xaf},
    {0xDE, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x35, 0x9e, 0x43, 0x6f, 0xd5, 0x95, 0x07, 0xbc, 0x6a},
    {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x45, 0x42, 0xb0, 0x3a, 0x09, 0x89, 0x95, 0x79, 0xee},
    {0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x12, 0x00, 0x00, 0x00, 0x00, 0x65, 0xE4, 0x86, 0x60, 0x0f, 0xf9, 0x94, 0x0b, 0x13, 0x7c, 0x2b, 0xe7}};

void connectToWifi(const char *ssid, const char *password)
{
    printf("Connecting to WiFi...\n");
    printf("SSID: %s\n", ssid);
    printf("Password: %s\n", password);
}

int isWiFiConnected()
{
    return 1; // Assuming WiFi is always connected in this dummy implementation
}

void parseCommand(const uint8_t *data, int data_length, void (*readCallback)(const uint8_t *, size_t), void (*notifyCallback)(const uint8_t *, size_t))
{
    printf("Command Received\n");

    for (int i = 0; i < data_length; i++)
    {
        printf("%d ", data[i]); // Print the element
    }
    printf("\n");

    if (data_length == 0)
    {
        printf("Received empty data.\n");
        return;
    }
    if (data[0] != 0x01)
    { // Start of header check
        printf("Invalid start of header.\n");
        return;
    }
    if (data_length < 2 || data_length != data[1])
    {
        printf("Data length mismatch.\n");
        return;
    }

    uint8_t cmd = data[3]; // CMD
    switch (cmd)
    {
    case 0x010:
        startOrStopRecording(data, data_length, readCallback, notifyCallback);
        break;
    case 0x05:
        getTimeSync(data, data_length, readCallback);
        break;
    case 0x06:
        setTimeSync(data, data_length, readCallback);
        break;
    case 0x1C:
        setWifiConfig(data, data_length, readCallback);
        break;
    case 0x1D:
        getWifiConfig(data, data_length, readCallback);
        break;
    case 0x16:
        getDashboardInfoBowl(data, data_length, readCallback);
        break;
    case 0x1A:
        setDogSize(data, data_length, readCallback);
        break;
    case 0x11:
        ReadRecordingSessionDetails(data, data_length, readCallback);
        break;
    case 0x12:
        ReadRecordingSessionData(data, data_length, readCallback);
        break;
    case 0x13:
        ReadRecordingSessionDetailsActivity(data, data_length, readCallback);
        break;
    case 0x14:
        ReadRecordingSessionDataActivity(data, data_length, readCallback);
        break;
    case 0x1E:
        getTotalSessionsCount(data, data_length, readCallback);
        break;
    case 0x1F:
        getSessionByIndex(data, data_length, readCallback);
        break;
    case 0x20:
        setSensorForBowl(data, data_length, readCallback);
        break;
    default:
        printf("Unknown or unsupported command.\n");
        break;
    }
}

void startOrStopRecording(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t), void (*notifyCallback)(const uint8_t *, size_t))
{
    // bool startStop = data[12] == 0x01; // Start/Stop flag
    bool startStop = data[4] == 0x01; // Start/Stop flag

    uint8_t additionalData[1] = {0x00}; // Additional data for the acknowledgment

    if (startStop)
    {
        sendAck(0x10, additionalData, sizeof(additionalData), readCallback);
        printf("Harvesting Started\n");
        //uint8_t sensorbyte = data[13];
        //decodeSelection(sensorbyte);
    }
    else
    {
        sendAck(0x10, additionalData, sizeof(additionalData), readCallback);
        printf("Harvesting Stopped\n");
    }
}

void setWifiConfig(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    char wifiSSID[21] = {0}; // 20 characters + null terminator
    size_t ssidLen = data[4];
    size_t len1 = 5 + (20 - ssidLen);
    for (size_t i = len1; i <= 24; ++i)
    {
        wifiSSID[i - len1] = (char)data[i];
        // printf("Index for ssid: %d, Value: %c\n", i - len1, wifiSSID[i - len1]);
    }

    char wifiPassword[21] = {0}; // 20 characters + null terminator
    size_t passLen = data[25];

    size_t len2 = 26 + (20 - passLen);

    for (size_t i = len2; i <= 45; ++i)
    {
        wifiPassword[i - len2] = (char)data[i];
        // printf("Index for pass: %d, Value: %c\n", i - len2, wifiPassword[i - len2]);
    }

    // Print SSID and password
    printf("WiFi SSID: %s\n", wifiSSID);
    printf("WiFi Password: %s\n", wifiPassword);

    connectToWifi(wifiSSID, wifiPassword);
    printf("Status: %d\n", isWiFiConnected());

    uint8_t additionalData[1] = {0x00}; // Additional data for the acknowledgment
    sendAck(0x1C, additionalData, sizeof(additionalData), readCallback);
}

void getWifiConfig(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t additionalData[43] = {0}; // Initialize all elements to 0

    if (isWiFiConnected())
    {
        additionalData[42] = 0x01; // Index 43 in array (arrays are zero-based)
    }

    sendAck(0x1D, additionalData, sizeof(additionalData), readCallback);
}

void getDashboardInfoBowl(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t additionalData[] = {
        // Device Name ASCII Chars ("DeviceName")
        0x44, 0x65, 0x76, 0x69, 0x63, 0x65, 0x4E, 0x61,
        // Device Model Type Code
        0x05,
        // Application Firmware major version
        0x01,
        // Application Firmware minor version
        0x0,
        // Application Firmware patch version
        0x0,
        // Battery level
        0x2E,
        // Battery voltage higher byte
        0x01,
        // Battery voltage lower byte
        0x02,
        // Input Power higher byte
        0x02,
        // Input Power lower byte
        0x06,
        // Temperature higher byte
        0x07,
        // Temperature lower byte
        0x08};
    sendAck(0x16, additionalData, sizeof(additionalData), readCallback);
}

void setDogSize(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t additionalData[] = {

    };
    sendAck(0x1A, additionalData, sizeof(additionalData), readCallback);
}

void ReadRecordingSessionDetails(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t uid[8];
    for (int i = 0; i < 8; ++i)
    {
        uid[i] = data[i + 4];
    }

    size_t additionalDataSize = 10;
    uint8_t *additionalData = (uint8_t *)malloc(additionalDataSize * sizeof(uint8_t));
    if (additionalData == NULL)
    {
        // Handle memory allocation failure
        return;
    }

    for (int i = 0; i < 8; ++i)
    {
        additionalData[i] = uid[i];
    }
    additionalData[8] = 0x00;
    additionalData[9] = 0x01;

    sendAck(0x11, additionalData, additionalDataSize, readCallback);
}

void ReadRecordingSessionData(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    // Extract UID from the data
    uint8_t uid[8];
    memcpy(uid, data + 4, 8);

    // Prepare myVector
    uint8_t *myVector = (uint8_t *)malloc(253 * sizeof(uint8_t));
    if (myVector == NULL)
    {
        // Handle memory allocation failure
        return;
    }
    memset(myVector, 0, 253 * sizeof(uint8_t)); // Initialize all elements to 0
    myVector[0] = 0x02;
    myVector[1] = 0x01;
    memcpy(myVector + 5, uid, 8);

    // Append checksum and update length
    appendChecksumAndUpdateLength(myVector, (size_t)253);

    // Set the second byte to 0x01
    myVector[1] = 0x01;

    // Call the readCallback function with myVector
    readCallback(myVector, 253);

    // Free allocated memory
    free(myVector);
}

void ReadRecordingSessionDetailsActivity(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t uid[8];
    for (int i = 0; i < 8; ++i)
    {
        uid[i] = data[i + 4];
    }

    size_t additionalDataSize = 10;
    uint8_t *additionalData = (uint8_t *)malloc(additionalDataSize * sizeof(uint8_t));
    if (additionalData == NULL)
    {
        // Handle memory allocation failure
        return;
    }

    for (int i = 0; i < 8; ++i)
    {
        additionalData[i] = uid[i];
    }
    additionalData[8] = 0x00;
    additionalData[9] = 0x01;

    sendAck(0x13, additionalData, additionalDataSize, readCallback);
}

void ReadRecordingSessionDataActivity(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    // Extract UID from the data
    uint8_t uid[8];
    memcpy(uid, data + 4, 8);

    // Prepare myVector
    uint8_t *myVector = (uint8_t *)malloc(253 * sizeof(uint8_t));
    if (myVector == NULL)
    {
        // Handle memory allocation failure
        return;
    }
    memset(myVector, 0, 253 * sizeof(uint8_t)); // Initialize all elements to 0
    myVector[0] = 0x02;
    myVector[1] = 0x01;
    memcpy(myVector + 5, uid, 8);

    // Append checksum and update length
    appendChecksumAndUpdateLength(myVector, (size_t)253);

    // Set the second byte to 0x01
    myVector[1] = 0x01;

    // Call the readCallback function with myVector
    readCallback(myVector, 253);

    // Free allocated memory
    free(myVector);
}

void getTotalSessionsCount(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t additionalData[1] = {0x05};
    sendAck(0x1E, additionalData, sizeof(additionalData), readCallback);
}

void getSessionByIndex(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    uint8_t element = data[4];
    int index = (int)element;

    if (index >= 0 && index < 5)
    {
        uint8_t additionalData[27];
        for (int i = 0; i < 27; ++i)
        {
            additionalData[i] = sessionData[index][i];
        }
        sendAck(0x1F, additionalData, sizeof(additionalData), readCallback);
    }
    else
    {
        printf("Invalid session index\n");
    }
}

void setSensorForBowl(const uint8_t *data, size_t data_length, void (*readCallback)(const uint8_t *, size_t))
{
    // Prepare additionalData
    uint8_t additionalData[] = {0x00};
    uint8_t selection = data[4];
    int count;
    const char **selectedSensors = decodeSelection(selection, &count);

    printf("Selected sensors: ");
    for (int i = 0; i < count; i++) {
        printf("%s, ", selectedSensors[i]);
    }
    printf("\n");

    // Don't forget to free the allocated memory
    free(selectedSensors);

    // Call sendAck with appropriate parameters
    sendAck(0x20, additionalData, sizeof(additionalData), readCallback);
}

void appendChecksumAndUpdateLength(uint8_t *packet, size_t packet_size)
{
    packet[1] = (uint8_t)(packet_size + 2); // Update frame length
    uint16_t checksum = calculateChecksum(packet, packet_size);
    packet[packet_size] = (uint8_t)((checksum >> 8) & 0xFF); // CRC high byte
    packet[packet_size + 1] = (uint8_t)(checksum & 0xFF);    // CRC low byte
}

uint16_t calculateChecksum(const uint8_t *data, size_t data_length)
{
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < data_length; i++)
    {
        crc ^= data[i];

        for (uint8_t j = 0; j < 8; j++)
        {
            if (crc & 0x0001)
            {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else
            {
                crc >>= 1;
            }
        }
    }
    return crc;
}

void setTimeSync(const uint8_t *data, size_t dataSize, void (*readCallback)(const uint8_t *, size_t))
{
    const uint8_t additionalData[] = {0x00};
    size_t additionalDataSize = sizeof(additionalData) / sizeof(additionalData[0]);

    sendAck(0x06, additionalData, additionalDataSize, readCallback);
}

void getTimeSync(const uint8_t *data, size_t dataSize, void (*readCallback)(const uint8_t *, size_t))
{
    const uint8_t additionalData[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    size_t additionalDataSize = sizeof(additionalData) / sizeof(additionalData[0]);

    sendAck(0x05, additionalData, additionalDataSize, readCallback);
}

void sendAck(uint8_t cmd, const uint8_t *data, size_t data_length, void (*readOrNotifyCallback)(const uint8_t *, size_t))
{
    uint8_t ackPacket[100];
    size_t ackPacketSize = 0;

    ackPacket[ackPacketSize++] = 0x02; // SOH
    ackPacket[ackPacketSize++] = 0x08; // Frame Length
    ackPacket[ackPacketSize++] = 0xF2; // FT
    ackPacket[ackPacketSize++] = cmd;  // CMD

    if (cmd == 0x04)
    {
        if (isWiFiConnected())
        {
            ackPacket[ackPacketSize++] = 0x11; // ACK
        }
        else
        {
            ackPacket[ackPacketSize++] = 0x12; // Error
        }
    }
    else
    {
        ackPacket[ackPacketSize++] = 0x11; // ACK
    }

    for (size_t i = 0; i < data_length; ++i)
    {
        ackPacket[ackPacketSize++] = data[i];
    }

    appendChecksumAndUpdateLength(ackPacket, ackPacketSize);

    // printf("My value: %llu\n",ackPacketSize );

    readOrNotifyCallback(ackPacket, ackPacketSize + 2);
    // printf("My value: %llu\n",ackPacketSize+2 );
}
